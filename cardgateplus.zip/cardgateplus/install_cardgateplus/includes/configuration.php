<?php

// Version information
define('CARDGATEPLUS_PLUGIN_VERSION',	"1.0.12");
define('XCART_COMPATIBILITY',"X-Cart GOLD & PRO<br/>version 4.4.0 - 4.7.+");

// Default skin directory
define ('DEFAULT_SKIN',"/skin/common_files");

// XCART config
define('XCART_START',1);
define('XCART_CONFIG_FILE',"../config.php");

?>